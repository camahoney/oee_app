import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.core import AutoMateEngine

def main():
    print("Booting AutoMate System...")
    engine = AutoMateEngine()
    engine.run()

if __name__ == "__main__":
    main()