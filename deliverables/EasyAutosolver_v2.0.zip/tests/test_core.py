import unittest
import sys
import os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from src.core import EasyAutosolverEngine

class TestEasyAutosolver(unittest.TestCase):
    def test_init(self):
        engine = EasyAutosolverEngine()
        self.assertIsNotNone(engine)
        
    def test_data_fetch(self):
        engine = EasyAutosolverEngine()
        data = engine._fetch_data()
        self.assertEqual(len(data), 50)

if __name__ == '__main__':
    unittest.main()