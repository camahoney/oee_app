import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.core import AutosolverSyncEngine

def main():
    print("Booting AutosolverSync System...")
    engine = AutosolverSyncEngine()
    engine.run()

if __name__ == "__main__":
    main()