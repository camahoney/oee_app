import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.core import AutoSyncEngine

def main():
    print("Booting AutoSync System...")
    engine = AutoSyncEngine()
    engine.run()

if __name__ == "__main__":
    main()