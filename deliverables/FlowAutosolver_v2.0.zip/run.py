import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.core import FlowAutosolverEngine

def main():
    print("Booting FlowAutosolver System...")
    engine = FlowAutosolverEngine()
    engine.run()

if __name__ == "__main__":
    main()