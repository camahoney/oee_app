import unittest
import sys
import os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from src.core import AutosolverStackEngine

class TestAutosolverStack(unittest.TestCase):
    def test_init(self):
        engine = AutosolverStackEngine()
        self.assertIsNotNone(engine)
        
    def test_data_fetch(self):
        engine = AutosolverStackEngine()
        data = engine._fetch_data()
        self.assertEqual(len(data), 50)

if __name__ == '__main__':
    unittest.main()