import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.core import AutosolverStackEngine

def main():
    print("Booting AutosolverStack System...")
    engine = AutosolverStackEngine()
    engine.run()

if __name__ == "__main__":
    main()