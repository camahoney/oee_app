import unittest
import sys
import os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from src.core import EasyBaseEngine

class TestEasyBase(unittest.TestCase):
    def test_init(self):
        engine = EasyBaseEngine()
        self.assertIsNotNone(engine)
        
    def test_data_fetch(self):
        engine = EasyBaseEngine()
        data = engine._fetch_data()
        self.assertEqual(len(data), 50)

if __name__ == '__main__':
    unittest.main()