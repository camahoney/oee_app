import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.core import CloudSyncEngine

def main():
    print("Booting CloudSync System...")
    engine = CloudSyncEngine()
    engine.run()

if __name__ == "__main__":
    main()