# FlowMate

## Overview
Looking for a serious marketing partner (Shopify store, rev-share, long-term)

Thank you for your purchase! You have acquired a lifetime license for FlowMate for $99/mo (Early Access).

## Installation
1. Ensure you have Python 3.8+ installed.
2. Run `pip install -r requirements.txt` (if applicable).

## Usage
Run the main executable:
```bash
python run.py
```

## Structure
- `src/`: Core logic
- `tests/`: Unit tests
- `run.py`: Entry point

## Support
For any questions, contact support@flowmate.com