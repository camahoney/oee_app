import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.core import AutosolverMateEngine

def main():
    print("Booting AutosolverMate System...")
    engine = AutosolverMateEngine()
    engine.run()

if __name__ == "__main__":
    main()